
from qgis.PyQt.QtCore import QCoreApplication, QSettings, QVariant
from qgis.core import QgsProcessing, QgsProcessingAlgorithm, QgsProcessingMultiStepFeedback, QgsProcessingParameterVectorLayer, QgsProcessingUtils, QgsProcessingParameterString, QgsField, QgsProcessingParameterField



class PAEBMRouteID(QgsProcessingAlgorithm):

    ROTA = 'ROTA'
    CAMPO = 'CAMPO'
    CATEGORY_FIELD = 'CATEGORY_FIELD'

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterVectorLayer(
            self.ROTA, 
            'Rota de Fuga', 
            #types=[QgsProcessing.TypeVectorLine], 
            defaultValue=None)
        )

        self.addParameter(
            QgsProcessingParameterField(
            self.CATEGORY_FIELD, 
            'Campo com as categorias', 
            type=QgsProcessingParameterField.String, 
            parentLayerParameterName=self.ROTA, 
            allowMultiple=False, 
            defaultValue=None)
        )

        self.addParameter(
            QgsProcessingParameterString(
            self.CAMPO, 
            'Nome do Campo', 
            multiLine=False, 
            defaultValue='id_rota')
        )

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(0, model_feedback)
        results = {}
        outputs = {}

        rota_layer = QgsProcessingUtils.mapLayerFromString(
            parameters[self.ROTA], context)
        
        category_field = self.parameterAsString(parameters, self.CATEGORY_FIELD, context)
        
        campo = self.parameterAsString(parameters, self.CAMPO, context)

        rota_layer.startEditing()

        # Create a new field for the ID column
        id_field = QgsField(campo, QVariant.String)
        rota_layer.addAttribute(id_field)
        idx = rota_layer.fields().indexFromName(campo)

        # Define a dictionary to hold the count values for each category
        count_dict = {}

        # Loop through the features and update the ID field
        for feat in rota_layer.getFeatures():
            category = feat[category_field]
            if category not in count_dict:
                count_dict[category] = 1
            feat[idx] = "Rota " + str(count_dict[category])
            count_dict[category] += 1
            rota_layer.updateFeature(feat)

        # Commit the changes and exit the editing session
        rota_layer.commitChanges()

        results[self.ROTA] = rota_layer

        return results

    def name(self):
        return 'id_rota_de_fuga' 

    def displayName(self):
        return 'ID Rota de Fuga'

    def group(self):
        """
        Returns the name of the group this algorithm belongs to. This string
        should be localised.
        """
        # return self.tr(self.groupId())
        return "Rota de Fuga"

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs to. This
        string should be fixed for the algorithm, and must not be localised.
        The group id should be unique within each provider. Group id should
        contain lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'rota_fuga'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    '''
    def shortHelpString(self):
        html_dir = os.path.join(os.path.dirname(__file__), 'help_delineation_flow.html')
        with open(html_dir, 'r') as f:
            html_code = f.read()
        return self.tr(html_code)'''

    def createInstance(self):
        return PAEBMRouteID()



