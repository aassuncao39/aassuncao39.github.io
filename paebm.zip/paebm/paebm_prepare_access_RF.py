# -*- coding: utf-8 -*-

__author__ = 'TTEK'
__date__ = '2022-09-11'
__copyright__ = '(C) 2022 by TTEK'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import processing
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterField,
                       QgsProcessingMultiStepFeedback,
                       QgsField, QgsProcessingParameterFeatureSink)
import os


class PAEBMRoutesCalculate(QgsProcessingAlgorithm):
    
    SIST_VIARIO = 'SISTEMA_VIARIO'
    CAMPO_DECLIVIDADE = 'DECLIVIDADE'
    SAIDA_SIST_VIARIO = 'SAIDA_SISTEMA_VIARIO'
    VELOCIDADE_A = 'VELOCIDADE_ANDANDO'
    VELOCIDADE_C = 'VELOCIDADE_CARRO'
    TEMPO_PRE_MOV = 'TEMPO_PRE_MOV'


    def initAlgorithm(self, config):
        """
        Metodo para a insercao dos parametros. Configuracao de tela e limitacao de parametros de entrada no formulario

        Inputs
        ------------------
        PONTO_EXUTORIO: QgsProcessingParameterPoint
            interacao do usuario para clicar em algum ponto do mapa
        DRENAGEM_INPUT: QgsProcessing.TypeVectorLine
            arquivo da drenagem
        DRENAGEM_DIRECTION_INPUT: Raster (.tif)
            arquivo de direcao de drenagem

        Parameters
        -----------------
        INTENSIDADE_INPUT: float
            intensidade em (mm/hr)
        RUNOFF_INPUT: float
            % de abstracoes

        Outputs
        -----------------
        AREA_CONTRIBUICAO: QgsProcessing.TypeVectorPolygon
            arquivo com a representacao da area de contribuicao e calculos dentro do arquivo
        EXUTORIO: QgsProcessing.TypeVectorPoint
            ponto marcado pelo usuario com o snap 
        """

        #----------INPUT----------------#

        #----------SISTEMA VIARIO----------------#
        self.addParameter(      
            QgsProcessingParameterFeatureSource(
                self.SIST_VIARIO,
                self.tr('Sistema Viário Particionado (input)'),
                [QgsProcessing.TypeVectorLine]
            )
        )

        #----------CAMPO COM DECLIVIDADE----------------#
        self.addParameter(      
            QgsProcessingParameterField(
                self.CAMPO_DECLIVIDADE,
                self.tr('Campo com a declividade (input)'),
                parentLayerParameterName=self.SIST_VIARIO
            )
        )

        
        #----------VELOCIDADE A PÉ----------------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.VELOCIDADE_A,
                self.tr('Velocidade a pé (input)'),
                type=QgsProcessingParameterNumber.Double,
                minValue = 0,
                maxValue=5,
                optional=False,
                defaultValue=1.27
            )
        )


        #----------VELOCIDADE DE CARRO----------------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.VELOCIDADE_C,
                self.tr('Velocidade de carro (input)'),
                type=QgsProcessingParameterNumber.Double,
                minValue = 0,
                maxValue=60,
                optional=False,
                defaultValue=30
            )
        )

        #----------TEMPO DE PRÉ-MOVIMENTO----------------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TEMPO_PRE_MOV,
                self.tr('Tempo Pré-Movimento (minutos)'),
                type = QgsProcessingParameterNumber.Double,
                minValue = 0,
                maxValue = 10,
                optional = False,
                defaultValue = 10
            )
        )

        
        #----------OUTPUTS----------------#
        #----------SISTEMA VIARIO COM CALCULOS-------#
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.SAIDA_SIST_VIARIO,
                self.tr('Sistema Viário com cálculos (output)'),
                type=QgsProcessing.TypeVectorAnyGeometry, 
                createByDefault=True, 
                defaultValue=None
            )
        )



    def processAlgorithm(self, parameters, context, feedback):

        # instancia a barra de status de processamento
        feedback = QgsProcessingMultiStepFeedback(2, feedback)

        results = {}  # cria dicionario de resultados
        outputs = {}  # cria dicionario de outputs

        feedback.setCurrentStep(1)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}

        #-------------CONCATENA VALORES E CALCULA VAZAO PARA O EXUTORIO COM O METODO RACIONAL----------#
        sist_viario_layer = self.parameterAsLayer(
            parameters, self.SIST_VIARIO, context) #passa a area de contribuicao para uma QgsVectorLayer
        
        feedback.pushInfo("Layer:{}".format(sist_viario_layer))


        declividade_field = self.parameterAsString(parameters, self.CAMPO_DECLIVIDADE, context)
        #feedback.pushInfo("Declividade field: {}".format(declividade_field))


        # define the field name and data type
        field_name_list = [
            'decli_rec', 
            'v_ape_inp',
            'v_car_inp', 
            'tp_pre_mov', 
            'comp_m', 
            'tp_ape_min', 
            'tp_car_min'
        ]
        
        field_type = QVariant.Double

        # check if the field already exists
        for field_name in field_name_list:

            if field_name in [f.name() for f in sist_viario_layer.fields()]:
                #print(f"The field '{field_name}' already exists in the layer.")
                pass
            else:
                # create a new field
                field = QgsField(field_name, field_type)
                sist_viario_layer.dataProvider().addAttributes([field])
                sist_viario_layer.updateFields()
                #print(f"The field '{field_name}' has been added to the layer.")

        '''#adiciona colunas a layer
        sist_viario_layer.dataProvider().addAttributes([
            QgsField('decli_rec', QVariant.Double),
            QgsField('v_ape_inp', QVariant.Double),
            QgsField('v_car_inp', QVariant.Double),
            QgsField('tp_pre_mov', QVariant.Double),
            QgsField('comp_m', QVariant.Double),
            QgsField('tp_ape_min', QVariant.Double),
            QgsField('tp_car_min', QVariant.Double)
        ])'''

        #sist_viario_layer.updateFields() #atualiza

        batch_size = 1000

        feature_count = sist_viario_layer.featureCount()
        feedback.pushInfo("n_features = {}".format(feature_count))
        i = 0

        sist_viario_layer.startEditing()  # inicia a edicao

        # pega o valor da velocidade andando
        vel_ape_inp = self.parameterAsDouble(
            parameters, self.VELOCIDADE_A, context)

        # pega o valor da velocidade dirigindo
        vel_carr_inp = self.parameterAsDouble(
            parameters, self.VELOCIDADE_C, context)

        # pega o valor do tempo pre movimento velocidade dirigindo
        temp_pre_mov = self.parameterAsDouble(
            parameters, self.TEMPO_PRE_MOV, context)

        declividade_rec_cat = {
            100: (0, 0),
            90: (0, 5),
            80: (5, 15),
            40: (15, 30),
            15: (30, 45),
            5: (45, 100)
        }



        iter = sist_viario_layer.getFeatures() #pega as features da layer

            # start an edit session for the layer

            # iterate over the features in the layer
        for feature in iter:
            declividade = feature[declividade_field]
            category = None

            # check which category the slope value falls into
            for cat, range_ in declividade_rec_cat.items():
                if range_[0] < declividade <= range_[1]:
                    category = cat
                    break

            # update the attribute value for the current feature
            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('decli_rec'), category)



            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('v_ape_inp'), vel_ape_inp)  # concatena valor de vel andando
            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('v_car_inp'), vel_carr_inp)  # concatena valor de vel dirigindo

            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('tp_pre_mov'), temp_pre_mov)  # concatena valor do tempo pre movimento

            
            comprimento = float(feature.geometry().length()) #calcula o comprimento da feature

            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('comp_m'), comprimento)  # concatena valor da area
            
            temp_ape = round(temp_pre_mov + ((comprimento / (vel_ape_inp * (category/100))) / 60), 4)

            temp_carro = round(temp_pre_mov + ((comprimento / (vel_carr_inp * (category/100))) / 60), 4)
            

            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('tp_ape_min'), temp_ape)  # concatena valor do metodo racional
            
            sist_viario_layer.changeAttributeValue(
                feature.id(), sist_viario_layer.dataProvider().fieldNameIndex('tp_car_min'), temp_carro)  # concatena valor do metodo racional
        


        sist_viario_layer.commitChanges()  # finaliza edicoes


        feedback.setCurrentStep(2)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}

        return {'OUTPUT': 'output'}

    def name(self):
        """
        Returns the algorithm name, used for identifying the algorithm. This
        string should be fixed for the algorithm, and must not be localised.
        The name should be unique within each provider. Names should contain
        lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'sist_viario_calculo'

    def displayName(self):
        """
        Returns the translated algorithm name, which should be used for any
        user-visible display of the algorithm name.
        """
        #return self.tr(self.name())
        return 'Cálculos Sistema Viário'

    def group(self):
        """
        Returns the name of the group this algorithm belongs to. This string
        should be localised.
        """
        # return self.tr(self.groupId())
        return "Rota de Fuga"

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs to. This
        string should be fixed for the algorithm, and must not be localised.
        The group id should be unique within each provider. Group id should
        contain lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'rota_fuga'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    '''
    def shortHelpString(self):
        html_dir = os.path.join(os.path.dirname(__file__), 'help_delineation_flow.html')
        with open(html_dir, 'r') as f:
            html_code = f.read()
        return self.tr(html_code)
    '''

    def createInstance(self):
        return GpxAnalyzerAlgorithmRoutesCalculate()

