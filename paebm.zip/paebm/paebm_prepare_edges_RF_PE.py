# -*- coding: utf-8 -*-

__author__ = 'TTEK'
__date__ = '2022-09-11'
__copyright__ = '(C) 2022 by TTEK'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import processing
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterField,
                       QgsProcessingMultiStepFeedback,
                       QgsField, QgsProcessingParameterFeatureSink, QgsProject)



class PAEBMPrepareEdgesRoutesPoints(QgsProcessingAlgorithm):
    
    SIST_VIARIO = 'SIST_VIARIO'
    CAMPO_DECLIVIDADE = 'CAMPO_DECLIVIDADE'
    SAIDA_SIST_VIARIO = 'SAIDA_SIST_VIARIO'
    VELOCIDADE_A = 'VELOCIDADE_A'
    VELOCIDADE_C = 'VELOCIDADE_C'
    TEMPO_PRE_MOV = 'TEMPO_PRE_MOV'

    def initAlgorithm(self, config):
        """
        Metodo para a insercao dos parametros. Configuracao de tela e limitacao de parametros de entrada no formulario

        Inputs
        ------------------
        PONTO_EXUTORIO: QgsProcessingParameterPoint
            interacao do usuario para clicar em algum ponto do mapa
        DRENAGEM_INPUT: QgsProcessing.TypeVectorLine
            arquivo da drenagem
        DRENAGEM_DIRECTION_INPUT: Raster (.tif)
            arquivo de direcao de drenagem

        Parameters
        -----------------
        INTENSIDADE_INPUT: float
            intensidade em (mm/hr)
        RUNOFF_INPUT: float
            % de abstracoes

        Outputs
        -----------------
        AREA_CONTRIBUICAO: QgsProcessing.TypeVectorPolygon
            arquivo com a representacao da area de contribuicao e calculos dentro do arquivo
        EXUTORIO: QgsProcessing.TypeVectorPoint
            ponto marcado pelo usuario com o snap 
        """

        #----------INPUT----------------#

        #----------SISTEMA VIARIO----------------#
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.SIST_VIARIO,
                self.tr('Sistema Viário Particionado (input)'),
                [QgsProcessing.TypeVectorLine]
            )
        )

        #----------CAMPO COM DECLIVIDADE----------------#
        self.addParameter(
            QgsProcessingParameterField(
                self.CAMPO_DECLIVIDADE,
                self.tr('Campo com a declividade (input)'),
                parentLayerParameterName=self.SIST_VIARIO
            )
        )

        #----------VELOCIDADE A PÉ----------------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.VELOCIDADE_A,
                self.tr('Velocidade a pé (input)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0,
                maxValue=5,
                optional=False,
                defaultValue=1.27
            )
        )

        #----------VELOCIDADE DE CARRO----------------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.VELOCIDADE_C,
                self.tr('Velocidade de carro (input)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0,
                maxValue=60,
                optional=False,
                defaultValue=30
            )
        )

        #----------TEMPO DE PRÉ-MOVIMENTO----------------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TEMPO_PRE_MOV,
                self.tr('Tempo Pré-Movimento (minutos)'),
                type=QgsProcessingParameterNumber.Double,
                minValue=0,
                maxValue=10,
                optional=False,
                defaultValue=10
            )
        )

        #----------OUTPUTS----------------#
        #----------SISTEMA VIARIO COM CALCULOS-------#
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.SAIDA_SIST_VIARIO,
                self.tr('Sistema Viário com cálculos (output)'),
                type=QgsProcessing.TypeVectorAnyGeometry,
                createByDefault=True,
                defaultValue=None
            )
        )

        

    def processAlgorithm(self, parameters, context, feedback):

        # instancia a barra de status de processamento
        feedback = QgsProcessingMultiStepFeedback(7, feedback)

        results = {}  # cria dicionario de resultados
        outputs = {}  # cria dicionario de outputs

        # Define the input layer and field to classify
        #input_layer = 'path/to/your/layer.shp'
        #input_field = 'Slope'

        # Define the output layer and field for the classification result
        #output_layer = 'path/to/output/layer.shp'
        #output_field = 'Slope_class'

        declividade_field = self.parameterAsString(
            parameters, self.CAMPO_DECLIVIDADE, context)

        # Define the class breaks and labels
        class_breaks = [0, 10, 20, 30, 40, 90]
        class_labels = ['Flat', 'Gentle', 'Moderate', 'Steep', 'Very steep']

        #formula = '"{}" ^ 2'.format(declividade_field)

        formula = '''
        CASE 
            WHEN "{0}" <= 0 THEN 100
            WHEN "{0}" <= 5 THEN 90
            WHEN "{0}" <= 15 THEN 80
            WHEN "{0}" <= 30 THEN 40
            WHEN "{0}" <= 45 THEN 15
            ELSE 5
        END'''.format(declividade_field)

        #feedback.pushInfo(formula)

        # Add a new field to the output layer to hold the classification result
        field_calculator_1 = processing.run("qgis:fieldcalculator", {
            'INPUT': parameters[self.SIST_VIARIO],
            'FIELD_NAME': 'decli_rec',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })

        outputs['FieldCalculator1'] = field_calculator_1['OUTPUT']

        feedback.setCurrentStep(1)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}
        
        # Add a new field to the output layer to hold the classification result

        # pega o valor da velocidade andando
        vel_ape_inp = self.parameterAsDouble(
            parameters, self.VELOCIDADE_A, context)

        formula = vel_ape_inp


        field_calculator_2 = processing.run("qgis:fieldcalculator", {
            'INPUT': outputs['FieldCalculator1'],
            'FIELD_NAME': 'v_ape_inp',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })

        outputs['FieldCalculator2'] = field_calculator_2['OUTPUT']

        feedback.setCurrentStep(2)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}
        
        vel_carr_inp = self.parameterAsDouble(
            parameters, self.VELOCIDADE_C, context)

        formula = vel_carr_inp

        field_calculator_3 = processing.run("qgis:fieldcalculator", {
            'INPUT': outputs['FieldCalculator2'],
            'FIELD_NAME': 'v_car_inp',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })

        outputs['FieldCalculator3'] = field_calculator_3['OUTPUT']

        feedback.setCurrentStep(3)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}
        
        # pega o valor do tempo pre movimento velocidade dirigindo
        temp_pre_mov = self.parameterAsDouble(
            parameters, self.TEMPO_PRE_MOV, context)

        formula = temp_pre_mov

        field_calculator_4 = processing.run("qgis:fieldcalculator", {
            'INPUT': outputs['FieldCalculator3'],
            'FIELD_NAME': 'tp_pre_mov',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })

        outputs['FieldCalculator4'] = field_calculator_4['OUTPUT']

        feedback.setCurrentStep(4)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}
        
        # pega o valor do tempo pre movimento velocidade dirigindo


        formula = '$length'

        field_calculator_5 = processing.run("qgis:fieldcalculator", {
            'INPUT': outputs['FieldCalculator4'],
            'FIELD_NAME': 'comp_m',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })

        outputs['FieldCalculator5'] = field_calculator_5['OUTPUT']

        feedback.setCurrentStep(5)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}
        
        formula = '''"{0}" + ("{1}"/("{2}"*("{3}"/100)))/60'''.format(
            'tp_pre_mov', 'comp_m', 'v_ape_inp', 'decli_rec')
        
        feedback.pushInfo(formula)


        field_calculator_6 = processing.run("qgis:fieldcalculator", {
            'INPUT': outputs['FieldCalculator5'],
            'FIELD_NAME': 'tp_ape_min',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })

        outputs['FieldCalculator6'] = field_calculator_6['OUTPUT']

        feedback.setCurrentStep(6)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}
        
        formula = '''"{0}" + ("{1}"/("{2}"*("{3}"/100)))/60'''.format(
                'tp_pre_mov', 'comp_m', 'v_car_inp', 'decli_rec')

        feedback.pushInfo(formula)

        field_calculator_7 = processing.runAndLoadResults("qgis:fieldcalculator", {
            'INPUT': outputs['FieldCalculator6'],
            'FIELD_NAME': 'tp_car_min',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 3,
            'FORMULA': formula,
            'OUTPUT': parameters[self.SAIDA_SIST_VIARIO]
        })

        outputs['FieldCalculator7'] = field_calculator_7['OUTPUT']

        feedback.setCurrentStep(7)  # atualiza barra de status de processamento
        if feedback.isCanceled():
            return {}

        # adiciona o resultado da poligonizacao no output
        
        results[self.SAIDA_SIST_VIARIO] = outputs['FieldCalculator7']

        #QgsProject.instance().addMapLayer(field_calculator_7['OUTPUT'])

        # adiciona o resultado da poligonizacao nos resultados

        return results

    def name(self):
        """
        Returns the algorithm name, used for identifying the algorithm. This
        string should be fixed for the algorithm, and must not be localised.
        The name should be unique within each provider. Names should contain
        lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'preparo_edges_rf_pe'

    def displayName(self):
        """
        Returns the translated algorithm name, which should be used for any
        user-visible display of the algorithm name.
        """
        #return self.tr(self.name())
        return 'Preparo Rotas PE-RF'

    def group(self):
        """
        Returns the name of the group this algorithm belongs to. This string
        should be localised.
        """
        # return self.tr(self.groupId())
        return "Rota de Fuga"

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs to. This
        string should be fixed for the algorithm, and must not be localised.
        The group id should be unique within each provider. Group id should
        contain lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'rota_fuga'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    '''
    def shortHelpString(self):
        html_dir = os.path.join(os.path.dirname(__file__), 'help_delineation_flow.html')
        with open(html_dir, 'r') as f:
            html_code = f.read()
        return self.tr(html_code)
    '''

    def createInstance(self):
        return PAEBMPrepareEdgesRoutesPoints()

