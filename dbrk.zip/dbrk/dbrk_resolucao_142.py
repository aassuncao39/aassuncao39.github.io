# -*- coding: utf-8 -*-

"""
/***************************************************************************
 DBRK - Resolução 142                             

                              -------------------
        begin                : 2024-03-08
        copyright            : (C) 2024 by Tetra Tech Inc
        email                : alexandre.assuncao@tetratech.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   Este codigo segue o manual de formatação do arquivo da macha de       * 
 *   proposto pela ANM                                                     *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 ***************************************************************************/

__author__ = 'alexandre.assuncao'
__date__ = '2024-03-08'
__copyright__ = '(C) 2024 by Tetra Tech Inc'
"""
import processing
from datetime import datetime
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterEnum,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingUtils,
                       QgsVectorLayer, 
                       QgsVectorFileWriter, 
                       QgsField, 
                       QgsProject,
                       QgsProcessingParameterString,
                       QgsFields, 
                       QgsWkbTypes, 
                       QgsFeature, 
                       QgsCoordinateReferenceSystem, 
                       QgsCoordinateTransform, 
                       QgsGeometry)


class DBRKResolucao142(QgsProcessingAlgorithm):
    
    INPUT_ZAS = 'INPUT_ZAS'
    INPUT_ZSS = 'INPUT_ZSS'
    INPUT_ID = 'INPUT_ID'
    NOME_BARRAGEM = 'NOME_BARRAGEM'
    EMPREENDEDOR = 'EMPREENDEDOR'
    CNPJ = 'CNPJ'
    PROCMIN = 'PROCMIN'
    NUMERO_MANCHA = 'NUMERO_MANCHA'
    MODO_FALHA = 'MODO_FALHA'
    DATA = 'DATA'
    SAIDA = 'SAIDA'
    CRS = 'CRS'
    CRS_OPTIONS = ['SIRGAS2000 UTM 23S', 'SIRGAS2000 UTM 22S']

    def tr(self, string):
        """
        Returns a translatable string with the self.tr() function.
        """
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return DBRKResolucao142()

    def name(self):
        """
        Returns the algorithm name, used for identifying the algorithm. This
        string should be fixed for the algorithm, and must not be localised.
        The name should be unique within each provider. Names should contain
        lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'changemancha'

    def displayName(self):
        """
        Returns the translated algorithm name, which should be used for any
        user-visible display of the algorithm name.
        """
        return self.tr('Mancha Inundacao Resolucao 142')

    def group(self):
        """
        Returns the name of the group this algorithm belongs to. This string
        should be localised.
        """
        return self.tr('DBRK')

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs to. This
        string should be fixed for the algorithm, and must not be localised.
        The group id should be unique within each provider. Group id should
        contain lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'dbrk'

    def shortHelpString(self):
        """
        Returns a localised short helper string for the algorithm. This string
        should provide a basic description about what the algorithm does and the
        parameters and outputs associated with it..
        """
        return self.tr("O objetivo desse manual é padronizar a entrega da Mancha de Inundação, obrigatória para todos os empreendedores que possuem barragens de mineração. A padronização seguida é fruto do manual da ANM: https://www.gov.br/anm/pt-br/assuntos/barragens/manuais/manual_mancha_de_inundacao.\n\nFavor utilizar a ferramenta com as camadas já no CSR: SIRGAS 2000 (EPSG:4674)")

    def initAlgorithm(self, config=None):
        
        #-----------zas--------#
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_ZAS,
                self.tr('Arquivo ZAS'),
                [QgsProcessing.TypeVectorPolygon]
            )
        )


        #-----------zss--------#
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_ZSS,
                self.tr('Arquivo ZSS'),
                [QgsProcessing.TypeVectorPolygon],
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.CRS,
                self.tr('Selecione a projeção para o cálculo da área'),
                options=self.CRS_OPTIONS
            )
        )

        #-----------id--------#
        self.addParameter(
            QgsProcessingParameterString(
                self.INPUT_ID,
                self.tr('ID (max 10 dígitos sem "." ou "/")'),
                optional = False

            )
        )

        #-----------nome barragem--------#
        self.addParameter(
            QgsProcessingParameterString(
                self.NOME_BARRAGEM,
                self.tr('Nome da barragem'),
                optional = False
            )
        )

        #-----------empreendedor--------#
        self.addParameter(
            QgsProcessingParameterString(
                self.EMPREENDEDOR,
                self.tr('Nome do empreendedor'),
                optional = False
            )
        )

        #----------cnpj--------#
        '''
        self.addParameter(
            QgsProcessingParameterNumber(
                self.CNPJ,
                self.tr('CNPJ'),
                type=QgsProcessingParameterNumber.Integer,
                optional = True,
                minValue=0,
                maxValue=99999999999999,  # 14 digits
                defaultValue=0
            )
        )
        '''
        self.addParameter(
            QgsProcessingParameterString(
                self.CNPJ,
                self.tr('CNPJ (14 dígitos sem "." ou "/")'),
                optional = True

            )
        )

        #----------processo minerario--------#
        self.addParameter(
            QgsProcessingParameterString(
                self.PROCMIN,
                self.tr('Processo Minerário (10 dígitos sem "." ou "/")'),
                optional = True

            )
        )

        #----------numero mancha de inundacao--------#
        self.addParameter(
            QgsProcessingParameterNumber(
                self.NUMERO_MANCHA,
                self.tr('Número da Mancha de Inundação'),
                type=QgsProcessingParameterNumber.Integer,
                optional = True
            )
        )

        #-----------modo de falaha--------#
        self.addParameter(
            QgsProcessingParameterString(
                self.MODO_FALHA,
                self.tr('Modo de Falha'),
                optional = True,
            )
        )

        #-----------data--------#
        self.addParameter(
            QgsProcessingParameterString(
                self.DATA,
                self.tr('Data (YYYY-MM-DD)')
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
              self.SAIDA,
              self.tr('Arquivo de saída'),
              createByDefault=True
          )
        )
     
    def verify_shapefile_crs(self, layer):
        
        # Get the CRS of the shapefile
        crs = layer.crs()

        parameter_dictionary = {
            'MESSAGE': 'A camada {} não está projetada'.format(layer),
            'CONDITION': crs.isGeographic()
        }
        
        # Check if the CRS is a projected coordinate system
        processing.run("native:raiseexception", parameter_dictionary)
        
        # CRS is projected
        return 

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(9, model_feedback)
        results = {}
        outputs = {}

        inputZAS=QgsProcessingUtils.mapLayerFromString(self.parameterAsString(parameters, self.INPUT_ZAS, context=context), context=context).dataProvider().dataSourceUri()
        #inputZAS = parameters[self.INPUT_ZAS]
        feedback.pushInfo(inputZAS)
        #inputZSS = parameters[self.INPUT_ZSS]
        if parameters[self.INPUT_ZSS]:
            inputZSS=QgsProcessingUtils.mapLayerFromString(self.parameterAsString(parameters, self.INPUT_ZSS, context=context), context=context).dataProvider().dataSourceUri()
            feedback.pushInfo(inputZSS)
        else:
            feedback.pushInfo("Nao foi inserida ZSS")

        
        idBarragem = parameters[self.INPUT_ID]
        nomeBarragem = parameters[self.NOME_BARRAGEM]
        empreend = parameters[self.EMPREENDEDOR]

        if parameters[self.CNPJ]:
            cnpj = int(parameters[self.CNPJ])
        else:
            cnpj = None
        if parameters[self.PROCMIN]:
            procMin = int(parameters[self.PROCMIN])
        else:
            procMin = None

        if parameters[self.NUMERO_MANCHA]:
            minNUM = parameters[self.NUMERO_MANCHA]
        else:
            minNUM = None
        
        if parameters[self.MODO_FALHA]:
            modoFalha = parameters[self.MODO_FALHA]
        else:
            modoFalha = None

        data = parameters[self.DATA]

        #data = datetime.strptime(data, "%Y-%m-%d")
        arquivoSaida = self.parameterAsFileOutput(
            parameters, self.SAIDA, context)
        #arquivoSaida = parameters[self.SAIDA]
        #arquivoSaida2=arquivoSaida.destinationName()
        feedback.pushInfo(f"{arquivoSaida}")

        #output.destinationName()

        # Create QgsField instances
        idField = QgsField(name='ID', type = QVariant.LongLong, len=10) #definido que ficará como 10, mesmo o ArcGIS não tendo possibilidade de demonstrar o dado;
        nomeBarragemField = QgsField(name = 'Barragem', type = QVariant.String, len=255)
        empreendField = QgsField(name = 'Empreend', type = QVariant.String, len=255)
        cnpjField = QgsField(name = 'CNPJ', type = QVariant.LongLong, len=14)
        procMinField = QgsField(name = 'ProcMin', type = QVariant.LongLong, len=10) #definido que ficará como 10, mesmo o ArcGIS não tendo possibilidade de demonstrar o dado;
        minNUMField = QgsField(name = 'MINum', type = QVariant.Int, len=2)
        zonaField = QgsField(name = 'Zona', type = QVariant.String, len=3)
        areaField = QgsField(name = 'Area', type = QVariant.Double, len = 15, prec=2)
        modoFalhaField = QgsField(name = 'ModFalha', type = QVariant.String, len=255)
        dataField = QgsField(name = 'Data', type = QVariant.Date)
        #dataField = QgsField(name = 'Data', type = QVariant.String, len=10)


        # Create a list of QgsField instances
        fields = [
            idField,
            nomeBarragemField,
            empreendField,
            cnpjField,
            procMinField,
            minNUMField,
            zonaField,
            areaField,
            modoFalhaField,
            dataField            
        ]

        dicionario_atributo_valor = {
            'ID': idBarragem, 
            'Barragem': nomeBarragem,
            'Empreend': empreend,
            'CNPJ': cnpj,
            'ProcMin': procMin,
            'MINum': minNUM,
            'ModFalha': modoFalha,
            'Data': data
        }

        fields_obj = QgsFields()
        for field in fields:
          fields_obj.append(field)

        layer1 = QgsVectorLayer(inputZAS, 'ZAS', 'ogr')
        #feedback.pushInfo(f"{type(layer1)}")
        #for feature in layer1.getFeatures():
            #print(feature.geometry().area())
        if parameters[self.INPUT_ZSS]:
            layer2 = QgsVectorLayer(inputZSS, 'ZSS', 'ogr')
        #feedback.pushInfo(f"{layer2}")


        # Create output layer writer
        geometry_type = QgsWkbTypes.Polygon
        #self.verify_shapefile_crs(layer1)
        crs = layer1.crs()

        selected_crs_index = parameters[self.CRS]
        selected_crs = self.CRS_OPTIONS[selected_crs_index]

        # Define the EPSG codes corresponding to the selected CRS
        if selected_crs == 'SIRGAS2000 UTM 23S':
            target_crs_epsg = 'EPSG:31983'
        elif selected_crs == 'SIRGAS2000 UTM 22S':
            target_crs_epsg = 'EPSG:31982'
        else:
            # Default to a known CRS if selection doesn't match
            target_crs_epsg = 'EPSG:4326'


        target_crs = QgsCoordinateReferenceSystem(target_crs_epsg)  # Change this to the CRS you need
        transform = QgsCoordinateTransform(crs, target_crs, QgsProject.instance())



        writer = QgsVectorFileWriter(arquivoSaida, 'UTF-8', fields_obj, geometry_type, srs=crs, driverName = 'ESRI Shapefile')
        #writer.startFeature(source_layer.sourceCrs())
        #lyr_output = QgsVectorLayer(arquivoSaida, 'Mancha Inundacao', 'ogr')
        id_feature=1
        #editingLayer = lyr_output.startEditing()
        #print(editingLayer)
        for feature in layer1.getFeatures():
            #feedback.pushInfo("Entrou aqui")
            new_feature = QgsFeature(fields_obj)
            transformed_geometry = QgsGeometry(feature.geometry())
            transformed_geometry.transform(transform)
            new_feature.setGeometry(feature.geometry())
            for idx, field in enumerate(fields):
                #if idx == 0:
                    #new_feature['ID'] = id_feature   # Modify attribute value as needed
                    #id_feature +=1
                if idx == 6:
                    new_feature['Zona'] = 'ZAS'
                elif idx == 7:
                    new_feature['Area'] = transformed_geometry.area()
                else:
                    new_feature[field.name()] = dicionario_atributo_valor.get(field.name())
            #print(new_feature.attributes())
            addFeature = writer.addFeature(new_feature)
            #updateFeature = lyr_output.updateFeature(new_feature)
            #print(addFeature)

        if parameters[self.INPUT_ZSS]:
            for feature in layer2.getFeatures():
                #feedback.pushInfo("Entrou aqui")
                new_feature = QgsFeature(fields_obj)
                new_feature.setGeometry(feature.geometry())
                transformed_geometry = QgsGeometry(feature.geometry())
                transformed_geometry.transform(transform)
                for idx, field in enumerate(fields):
                    #if idx == 0:
                        #new_feature['ID'] = id_feature   # Modify attribute value as needed
                        #id_feature +=1
                    if idx == 6:
                        new_feature['Zona'] = 'ZSS'
                    elif idx == 7:
                        new_feature['Area'] = transformed_geometry.area()
                    else:
                        new_feature[field.name()] = dicionario_atributo_valor.get(field.name())

                #print(new_feature.attributes())
                addFeature = writer.addFeature(new_feature)
                #updateFeature = lyr_output.updateFeature(new_feature)
                #print(addFeature)
        #commitChanges = lyr_output.commitChanges()
        #lyr_output.triggerRepaint()
        #print(commitChanges)
        del writer  # Don't forget to close the writer when you're done adding features

        results['OUTPUT'] = arquivoSaida
        return results

    def on_crs_selection_change(self, value):
        selected_crs = value
        if selected_crs == "SIRGAS2000 UTM 23S":
            target_crs_epsg = 'EPSG:31983'  # EPSG code for SIRGAS2000 UTM 23S
        elif selected_crs == "SIRGAS2000 UTM 22S":
            target_crs_epsg = 'EPSG:31982'  # EPSG code for SIRGAS2000 UTM 22S
        else:
            # Default to a known CRS if selection doesn't match
            target_crs_epsg = 'EPSG:4326'  # Defaulting to WGS84