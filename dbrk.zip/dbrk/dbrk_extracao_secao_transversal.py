from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFile,
                       QgsProcessingParameterMultipleLayers,
                       QgsProcessingParameterFileDestination,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterFolderDestination,
                       QgsProcessingParameterDefinition)
import processing
import os
#import pandas as pd
import time

try:
    from osgeo import osr, gdal, ogr
except:
    import subprocess
    subprocess.check_call(['python', '-m', 'pip', 'install', 'osgeo'])
    from osgeo import osr, gdal, ogr
import numpy as np
import pandas as pd
import os


class ExtracaoInformacaoRaster:     
    def __init__(self, list_of_rasters, list_of_vectors, output_folder, neighborhood_size=None):
        self.list_of_rasters = list_of_rasters
        self.list_of_vectors = list_of_vectors
        self.raster_path = None
        self.vector_path = None
        self.neighborhood_size = neighborhood_size
        self.pixel_value = None
        self.raster_name = None
        self.output_folder = output_folder
        #self.attr_dict = self.get_vector_attributes()
        #print(self.attr_dict)

        self.dictionary_acronyms = {
            'cheia_extraord': 'Cheia extraordinária',
            'cheia_ord': 'Cheia ordinária',
            'dseco': 'Ruptura em dia Seco',
            'dchuv': 'Ruptura em dia Chuvoso',
            'tempo_de_cheg': 'Tempo de Chegada da Onda de Ruptura - 2 pés',
            'velocidade_max': 'Velocidade Máxima Atingida no Ponto de Observação', 
            'wse_max': 'Elevação Máxima Atingida no Ponto de Observação',
            'risco_hidrodim_nao_class':  'Risco Hidrodinâmico',
            'profund_max': 'Profundidade Máxima Atingida no Ponto de Observação',
            'risco_hidrodim_class': 'Risco Hidrodinâmico Classificado' ,
            'tcheg_pico_onda': 'Tempo de Chegada da Onda de Ruptura - Pico',
        }
    
    
    def get_column_name(self):
        raster_name = os.path.basename(self.raster_path).split(".tif")[0]
        return raster_name

    def open_vector_and_get_vector(self):
        attr_dict={}
        vector_ds = ogr.Open(self.vector_path)
        if vector_ds is None:
            print("Error: Could not open vector dataset.")
            return
        self.vector_layer = vector_ds.GetLayer()
        for idx, f in enumerate(self.vector_layer):
            attributes = f.items()
            attr_dict[idx] = attributes
        self.attr_dict = attr_dict

    def update_vector_attributes(self, idx):
        #attributes = f.items()
        #attributes[self.raster_name] = self.pixel_value
        self.attr_dict[idx][self.raster_name] = self.pixel_value


    def extract_raster_values(self):
        print("entrou_aqui")
        gdal.SetConfigOption('GTIFF_SRS_SOURCE', 'EPSG') #set configuration to EPSG
        # Open raster dataset
        raster_ds = gdal.Open(self.raster_path)
        print(raster_ds)
        if raster_ds is None:
            print("Error: Could not open raster dataset.")
            return
        
        self.raster_name = self.get_column_name()
        print(self.raster_name)

        # Open vector dataset
        #vector_ds = ogr.Open(self.vector_path)
        #if vector_ds is None:
        #    print("Error: Could not open vector dataset.")
        #    return
        
        # Get raster band
        raster_band = raster_ds.GetRasterBand(1)

        # Create a spatial reference from raster
        raster_srs = raster_ds.GetProjectionRef()

        # Get vector layer
        #vector_layer = vector_ds.GetLayer()
        #feature_count = vector_layer.GetFeatureCount()
        #print(feature_count)
        #print(vector_layer.GetSpatialRef())
        # Create an in-memory raster
        mem_drv = gdal.GetDriverByName('MEM')
        mem_raster = mem_drv.Create('', raster_ds.RasterXSize, raster_ds.RasterYSize, 1, gdal.GDT_Float32)
        mem_raster.SetProjection(raster_srs)
        mem_raster.SetGeoTransform(raster_ds.GetGeoTransform())
        #print(mem_raster.GetProjectionRef())
        # Rasterize the vector layer onto the in-memory raster
        vector_ds = ogr.Open(self.vector_path)
        vector_layer = vector_ds.GetLayer()
        gdal.RasterizeLayer(mem_raster, [1], vector_layer, burn_values=[1])

        # Read the rasterized values
        raster_array = mem_raster.ReadAsArray()
        raster_input_array = raster_band.ReadAsArray()

        # Extract raster values along the vector geometry
        #pixel_values = []

        #vector_ds = ogr.Open(self.vector_path)
        print(vector_ds)
        #vector_layer = vector_ds.GetLayer()
        geom_transform = mem_raster.GetGeoTransform()

        for idx, f in enumerate(vector_layer):
            print(idx)
            point = f.GetGeometryRef()

            col, row = (point.GetX() - geom_transform[0]) /geom_transform[1], \
                    (point.GetY() - geom_transform[3]) / geom_transform[5]
            print(col, row)

            if col < 0 or row < 0:
                self.pixel_value = None

            #process for neighboors interpolation
            elif self.neighborhood_size:
                neighborhood = raster_input_array[int(row) - self.neighborhood_size:int(row)+self.neighborhood_size+1, int(col) - self.neighborhood_size:int(col)+self.neighborhood_size+1]
                self.pixel_value = np.nanmean(neighborhood)

            else: #process for extracting the exact point
                self.pixel_value = raster_input_array[int(row), int(col)]


            self.update_vector_attributes(idx)

        #df_all = pd.DataFrame(self.attr_dict).T

        # Cleanup
        raster_ds = None
        vector_ds = None
        mem_raster = None

        return

    def run_multiple(self):
        #layer_files = os.listdir(self.vector_folder_path)
        #vector_files = [file for file in layer_files if 'pto_observacao' in file and file.endswith('.shp')] #pensar em alternativa para o nome da camada

        # Get a list of all files in the folder
        #all_files = os.listdir(self.raster_folder_path)

        # Filter files with .tif extension
        #tif_files = [file for file in all_files if file.endswith('.tif')]

        scenario_patterns = ['cheia_extraord', 'cheia_ord', 'dseco', 'dchuv'] #pensar em alternativa ou pedir para padronizar

        for scen in scenario_patterns:
            print(scen)
            raster_paths = [file for file in self.list_of_rasters if scen in file]
            vector_paths = [layer for layer in self.list_of_vectors if scen in layer]
            print(vector_paths)
            if len(vector_paths) == 0 or len(raster_paths) == 0:
                continue
            #vector_path = os.path.join(self.vector_folder_path, vector_path)
            self.vector_path = vector_paths[0]
            #print(vector_path)
            self.open_vector_and_get_vector()
            #raster_path = raster_paths[0]
            #raster_path = os.path.join(raster_folder_path, raster_path)
            #print(raster_path)
            #df_new = pd.DataFrame()
            for raster_path in raster_paths:
                print(raster_path)
                self.raster_path = raster_path
                self.extract_raster_values()
                print(self.pixel_value)

            
            df_all = pd.DataFrame(self.attr_dict).T

            #print(f"DF NAME {self.dictionary_acronyms.get(scen)}")
            name_process = self.dictionary_acronyms.get(scen)
            #print(df_new)
            rename_dict = {}
            for col in df_all.columns:
                for key in self.dictionary_acronyms.keys():
                    if  key in col:
                        rename_dict[col] = self.dictionary_acronyms.get(key)
            df_all.rename(columns = rename_dict, inplace=True)
            output_folder_excel = os.path.join(self.output_folder, f"{name_process}.xlsx")
            print(output_folder_excel)
            df_all.to_excel(output_folder_excel)
        return df_all


# Import the module
#from extract_info_gdal import your_function

#from extract_info_gdal import ExtracaoInformacaoRaster

class DBRKExtracaoInfoSecao(QgsProcessingAlgorithm):
    """
    This is an example algorithm that takes a vector layer,
    creates some new layers and returns some results.
    """

    INPUT_LAYERS = 'INPUT_LAYERS'
    INPUT_RASTERS = 'INPUT_RASTERS'
    INPUT_FOLDER = 'INPUT_FOLDER'
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'
    INPUT_N_NEIGHBORS = 'INPUT_N_NEIGHBORS'
    

    def tr(self, string):
        """
        Returns a translatable string with the self.tr() function.
        """
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        # Must return a new copy of your algorithm.
        return DBRKExtracaoInfoSecao()

    def name(self):
        """
        Returns the unique algorithm name.
        """
        return 'extracaosecaoinfo'

    def displayName(self):
        """
        Returns the translated algorithm name.
        """
        return self.tr('Extração Info Seção Transversal')

    def group(self):
        """
        Returns the name of the group this algorithm belongs to.
        """
        return self.tr('DBRK')

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs
        to.
        """
        return 'dbrk'

    def shortHelpString(self):
        """
        Returns a localised short help string for the algorithm.
        """
        return self.tr('Extrai informações da seção transversal')

    def initAlgorithm(self, config=None):
        """
        Here we define the inputs and outputs of the algorithm.
        """
        # 'INPUT' is the recommended name for the main input
        # parameter.
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                self.tr('Input vector layers'),
                layerType = QgsProcessing.TypeVectorAnyGeometry
            )
        )

        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_RASTERS,
                self.tr('Input rasters layers'),
                layerType = QgsProcessing.TypeRaster
            )
        )


        self.addParameter(
            QgsProcessingParameterNumber(
                self.INPUT_N_NEIGHBORS,
                self.tr('Number of Neighboors'),
                type=QgsProcessingParameterNumber.Integer
            )
        )
        
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_FOLDER,
                self.tr("Output folder")
            )
        )



    def processAlgorithm(self, parameters, context, feedback):
        """
        Here is where the processing itself takes place.
        """
        # First, we get the count of features from the INPUT layer.
        # This layer is defined as a QgsProcessingParameterFeatureSource
        # parameter, so it is retrieved by calling
        # self.parameterAsSource.
        start_time = time.time()
        vectorFiles = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        vectorFilesList = []
        for layer in vectorFiles:
            # Get the full path of the vector layer
            layerPath = layer.dataProvider().dataSourceUri()
            vectorFilesList.append(layerPath)
            #feedback.pushInfo(f'Processing vector layer: {layer_path}')

        rasterFiles = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        rasterFilesList = []
        for raster in rasterFiles:
            # Get the full path of the vector layer
            rasterPath = raster.dataProvider().dataSourceUri()
            rasterFilesList.append(rasterPath)


        neighborhoodSize = int(self.parameterAsString(parameters, self.INPUT_N_NEIGHBORS, context))
        outputFolder = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)

        classe_extract = ExtracaoInformacaoRaster(
            list_of_rasters = rasterFilesList, 
            list_of_vectors = vectorFilesList, 
            output_folder = outputFolder,
            neighborhood_size = None)
        
        df = classe_extract.run_multiple()
                

        return {'OUTPUT FILES': outputFolder}